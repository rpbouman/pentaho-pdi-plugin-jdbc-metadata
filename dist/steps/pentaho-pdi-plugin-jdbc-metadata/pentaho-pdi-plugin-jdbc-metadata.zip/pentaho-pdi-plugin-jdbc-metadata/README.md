pentaho-pdi-plugin-jdbc-metadata
================================

A transformation step for pentaho data integration that gives access to the various metadata resultsets of the JDBC DatabaseMetaData object.
